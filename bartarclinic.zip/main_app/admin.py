from django.contrib import admin
from .models import *

admin.site.register(contactClass)
admin.site.register(staticcontentClass)
admin.site.register(staticphotoClass)
admin.site.register(categoryClass)
admin.site.register(serviceClass)
admin.site.register(categorywsClass)
admin.site.register(workshopClass)
admin.site.register(therapeutistClass)
admin.site.register(scheduleClass)
admin.site.register(appointmentClass)
from django import forms
from .models import *

class contactForm (forms.ModelForm):
    class Meta:
        model=contactClass
        fields=['username','email','title','message']
        widgets={'username':forms.TextInput(attrs={'placeholder':"نام کاربری" , 'class':"form-control border-0 bg-light px-4" , 'style':"height: 55px;"}),
                 'email':forms.EmailInput(attrs={'placeholder':"آدرس ایمیل" , 'class':"form-control border-0 bg-light px-4" , 'style':"height: 55px;"}),
                 'title':forms.TextInput(attrs={'placeholder':"موضوع" , 'class':"form-control border-0 bg-light px-4" , 'style':"height: 55px;"}),
                 'message':forms.Textarea(attrs={'placeholder':"دیدگاه" , 'class':"form-control border-0 bg-light px-4 py-3", 'rows':"5"}),
                 }
        
 
class appointmentform(forms.ModelForm):
    class Meta:
        model=appointmentClass
        fields=['service','therapeutist','date','start_time','end_time','username','fullname']
        widgets={'service':forms.Select(attrs={'class':"form-select bg-light border-0",'style':"height: 55px;"}),
                       'therapeutist':forms.Select(attrs={'class':"form-select bg-light border-0",'style':"height: 55px;"}),
                       'date':forms.DateField(),
                       'start_time':forms.TimeField(),
                       'end_time':forms.TimeField(),
                       'username':forms.TextInput(),
                       'fullname':forms.TextInput(),
                       

                 }
        